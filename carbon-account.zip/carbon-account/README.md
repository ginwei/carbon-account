# carbon-account
use the blockchain to store the data of carbon account. 

aim to provide the system for cooperation to choose the best carbon account calculation, and get the data in the past.
